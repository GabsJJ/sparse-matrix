﻿namespace _18196_18204_Projeto1ED
{
    partial class frmMatriz
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnExcluirMatriz1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudColunas1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nudLinhas1 = new System.Windows.Forms.NumericUpDown();
            this.btnLerArq1 = new System.Windows.Forms.Button();
            this.btnCriar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRemover = new System.Windows.Forms.Button();
            this.btnInserir = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nudColunas3 = new System.Windows.Forms.NumericUpDown();
            this.cbxMatrizes = new System.Windows.Forms.ComboBox();
            this.nudLinhas3 = new System.Windows.Forms.NumericUpDown();
            this.dgvMatriz1 = new System.Windows.Forms.DataGridView();
            this.dgvMatriz2 = new System.Windows.Forms.DataGridView();
            this.dgvMatriz3 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbxDuasMatrizesAmultiplicar = new System.Windows.Forms.ComboBox();
            this.btnMulti = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.btnSomarDuasMatrizes = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.cbxMatriz3 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.nudColuna5 = new System.Windows.Forms.NumericUpDown();
            this.txtValor2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dlgMatriz1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnExcluirMatriz2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.nudColunas2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.nudLinhas2 = new System.Windows.Forms.NumericUpDown();
            this.btnLerArq2 = new System.Windows.Forms.Button();
            this.btnCriar2 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cbxMatrizes2 = new System.Windows.Forms.ComboBox();
            this.lblRetorno = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.nudColunas4 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.nudLinhas4 = new System.Windows.Forms.NumericUpDown();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz3)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColuna5)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas2)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas4)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnExcluirMatriz1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nudColunas1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.nudLinhas1);
            this.groupBox1.Controls.Add(this.btnLerArq1);
            this.groupBox1.Controls.Add(this.btnCriar);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 217);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Criação da matriz 1";
            // 
            // btnExcluirMatriz1
            // 
            this.btnExcluirMatriz1.Location = new System.Drawing.Point(103, 184);
            this.btnExcluirMatriz1.Name = "btnExcluirMatriz1";
            this.btnExcluirMatriz1.Size = new System.Drawing.Size(100, 27);
            this.btnExcluirMatriz1.TabIndex = 9;
            this.btnExcluirMatriz1.Text = "Excluir matriz";
            this.btnExcluirMatriz1.UseVisualStyleBackColor = true;
            this.btnExcluirMatriz1.Click += new System.EventHandler(this.btnPrintar1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Colunas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Linhas";
            // 
            // nudColunas1
            // 
            this.nudColunas1.Location = new System.Drawing.Point(71, 144);
            this.nudColunas1.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudColunas1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudColunas1.Name = "nudColunas1";
            this.nudColunas1.Size = new System.Drawing.Size(60, 23);
            this.nudColunas1.TabIndex = 6;
            this.nudColunas1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Criar a partir do programa:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Criar a partir de arquivo texto:";
            // 
            // nudLinhas1
            // 
            this.nudLinhas1.Location = new System.Drawing.Point(71, 115);
            this.nudLinhas1.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudLinhas1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudLinhas1.Name = "nudLinhas1";
            this.nudLinhas1.Size = new System.Drawing.Size(60, 23);
            this.nudLinhas1.TabIndex = 3;
            this.nudLinhas1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // btnLerArq1
            // 
            this.btnLerArq1.Location = new System.Drawing.Point(6, 46);
            this.btnLerArq1.Name = "btnLerArq1";
            this.btnLerArq1.Size = new System.Drawing.Size(90, 28);
            this.btnLerArq1.TabIndex = 1;
            this.btnLerArq1.Text = "Ler arquivo";
            this.btnLerArq1.UseVisualStyleBackColor = true;
            this.btnLerArq1.Click += new System.EventHandler(this.btnLerArq1_Click);
            // 
            // btnCriar
            // 
            this.btnCriar.Location = new System.Drawing.Point(6, 184);
            this.btnCriar.Name = "btnCriar";
            this.btnCriar.Size = new System.Drawing.Size(97, 27);
            this.btnCriar.TabIndex = 0;
            this.btnCriar.Text = "Criar matriz";
            this.btnCriar.UseVisualStyleBackColor = true;
            this.btnCriar.Click += new System.EventHandler(this.btnCriar_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRemover);
            this.groupBox2.Controls.Add(this.btnInserir);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtValor);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.nudColunas3);
            this.groupBox2.Controls.Add(this.cbxMatrizes);
            this.groupBox2.Controls.Add(this.nudLinhas3);
            this.groupBox2.Location = new System.Drawing.Point(650, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(220, 217);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inserir/Remover dados";
            // 
            // btnRemover
            // 
            this.btnRemover.Location = new System.Drawing.Point(87, 184);
            this.btnRemover.Name = "btnRemover";
            this.btnRemover.Size = new System.Drawing.Size(75, 27);
            this.btnRemover.TabIndex = 17;
            this.btnRemover.Text = "Remover";
            this.btnRemover.UseVisualStyleBackColor = true;
            this.btnRemover.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnInserir
            // 
            this.btnInserir.Location = new System.Drawing.Point(6, 184);
            this.btnInserir.Name = "btnInserir";
            this.btnInserir.Size = new System.Drawing.Size(75, 27);
            this.btnInserir.TabIndex = 10;
            this.btnInserir.Text = "Inserir";
            this.btnInserir.UseVisualStyleBackColor = true;
            this.btnInserir.Click += new System.EventHandler(this.button2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Valor";
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(71, 157);
            this.txtValor.MaxLength = 10000;
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(87, 23);
            this.txtValor.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Defina a linha, coluna e o valor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Coluna";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Escolha a matriz:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Linha";
            // 
            // nudColunas3
            // 
            this.nudColunas3.Location = new System.Drawing.Point(71, 128);
            this.nudColunas3.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudColunas3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColunas3.Name = "nudColunas3";
            this.nudColunas3.Size = new System.Drawing.Size(60, 23);
            this.nudColunas3.TabIndex = 11;
            this.nudColunas3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cbxMatrizes
            // 
            this.cbxMatrizes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMatrizes.FormattingEnabled = true;
            this.cbxMatrizes.Location = new System.Drawing.Point(9, 43);
            this.cbxMatrizes.Name = "cbxMatrizes";
            this.cbxMatrizes.Size = new System.Drawing.Size(112, 24);
            this.cbxMatrizes.TabIndex = 0;
            this.cbxMatrizes.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // nudLinhas3
            // 
            this.nudLinhas3.Location = new System.Drawing.Point(71, 99);
            this.nudLinhas3.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudLinhas3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudLinhas3.Name = "nudLinhas3";
            this.nudLinhas3.Size = new System.Drawing.Size(60, 23);
            this.nudLinhas3.TabIndex = 10;
            this.nudLinhas3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dgvMatriz1
            // 
            this.dgvMatriz1.AllowUserToAddRows = false;
            this.dgvMatriz1.AllowUserToDeleteRows = false;
            this.dgvMatriz1.AllowUserToResizeColumns = false;
            this.dgvMatriz1.AllowUserToResizeRows = false;
            this.dgvMatriz1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvMatriz1.Location = new System.Drawing.Point(12, 235);
            this.dgvMatriz1.Name = "dgvMatriz1";
            this.dgvMatriz1.ReadOnly = true;
            this.dgvMatriz1.Size = new System.Drawing.Size(378, 200);
            this.dgvMatriz1.TabIndex = 18;
            // 
            // dgvMatriz2
            // 
            this.dgvMatriz2.AllowUserToAddRows = false;
            this.dgvMatriz2.AllowUserToDeleteRows = false;
            this.dgvMatriz2.AllowUserToResizeColumns = false;
            this.dgvMatriz2.AllowUserToResizeRows = false;
            this.dgvMatriz2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvMatriz2.Location = new System.Drawing.Point(396, 235);
            this.dgvMatriz2.Name = "dgvMatriz2";
            this.dgvMatriz2.Size = new System.Drawing.Size(378, 200);
            this.dgvMatriz2.TabIndex = 19;
            // 
            // dgvMatriz3
            // 
            this.dgvMatriz3.AllowUserToAddRows = false;
            this.dgvMatriz3.AllowUserToDeleteRows = false;
            this.dgvMatriz3.AllowUserToResizeColumns = false;
            this.dgvMatriz3.AllowUserToResizeRows = false;
            this.dgvMatriz3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatriz3.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvMatriz3.Location = new System.Drawing.Point(396, 441);
            this.dgvMatriz3.Name = "dgvMatriz3";
            this.dgvMatriz3.Size = new System.Drawing.Size(378, 231);
            this.dgvMatriz3.TabIndex = 20;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbxDuasMatrizesAmultiplicar);
            this.groupBox3.Controls.Add(this.btnMulti);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.btnSomarDuasMatrizes);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.cbxMatriz3);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.btnSomar);
            this.groupBox3.Controls.Add(this.nudColuna5);
            this.groupBox3.Controls.Add(this.txtValor2);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Location = new System.Drawing.Point(12, 441);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(378, 231);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operações";
            // 
            // cbxDuasMatrizesAmultiplicar
            // 
            this.cbxDuasMatrizesAmultiplicar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDuasMatrizesAmultiplicar.FormattingEnabled = true;
            this.cbxDuasMatrizesAmultiplicar.Location = new System.Drawing.Point(6, 195);
            this.cbxDuasMatrizesAmultiplicar.Name = "cbxDuasMatrizesAmultiplicar";
            this.cbxDuasMatrizesAmultiplicar.Size = new System.Drawing.Size(112, 24);
            this.cbxDuasMatrizesAmultiplicar.TabIndex = 27;
            this.cbxDuasMatrizesAmultiplicar.Click += new System.EventHandler(this.cbxDuasMatrizesAmultiplicar_Click);
            // 
            // btnMulti
            // 
            this.btnMulti.Location = new System.Drawing.Point(124, 193);
            this.btnMulti.Name = "btnMulti";
            this.btnMulti.Size = new System.Drawing.Size(90, 27);
            this.btnMulti.TabIndex = 26;
            this.btnMulti.Text = "Multiplicar";
            this.btnMulti.UseVisualStyleBackColor = true;
            this.btnMulti.Click += new System.EventHandler(this.btnMulti_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 172);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(163, 17);
            this.label24.TabIndex = 25;
            this.label24.Text = "Multiplicar duas Matrizes";
            // 
            // btnSomarDuasMatrizes
            // 
            this.btnSomarDuasMatrizes.Location = new System.Drawing.Point(6, 132);
            this.btnSomarDuasMatrizes.Name = "btnSomarDuasMatrizes";
            this.btnSomarDuasMatrizes.Size = new System.Drawing.Size(75, 27);
            this.btnSomarDuasMatrizes.TabIndex = 24;
            this.btnSomarDuasMatrizes.Text = "Somar";
            this.btnSomarDuasMatrizes.UseVisualStyleBackColor = true;
            this.btnSomarDuasMatrizes.Click += new System.EventHandler(this.btnSomarDuasMatrizes_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 112);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(164, 17);
            this.label23.TabIndex = 23;
            this.label23.Text = "Somar as duas Matrizes:";
            // 
            // cbxMatriz3
            // 
            this.cbxMatriz3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMatriz3.FormattingEnabled = true;
            this.cbxMatriz3.Location = new System.Drawing.Point(57, 40);
            this.cbxMatriz3.Name = "cbxMatriz3";
            this.cbxMatriz3.Size = new System.Drawing.Size(60, 24);
            this.cbxMatriz3.TabIndex = 22;
            this.cbxMatriz3.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 43);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 17);
            this.label22.TabIndex = 21;
            this.label22.Text = "Matriz:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(119, 80);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 17);
            this.label21.TabIndex = 20;
            this.label21.Text = "Colunas:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 80);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 17);
            this.label20.TabIndex = 19;
            this.label20.Text = "Valor:";
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(250, 74);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(75, 27);
            this.btnSomar.TabIndex = 18;
            this.btnSomar.Text = "Somar";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // nudColuna5
            // 
            this.nudColuna5.Location = new System.Drawing.Point(188, 77);
            this.nudColuna5.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudColuna5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColuna5.Name = "nudColuna5";
            this.nudColuna5.Size = new System.Drawing.Size(56, 23);
            this.nudColuna5.TabIndex = 17;
            this.nudColuna5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // txtValor2
            // 
            this.txtValor2.Location = new System.Drawing.Point(57, 77);
            this.txtValor2.MaxLength = 10000;
            this.txtValor2.Name = "txtValor2";
            this.txtValor2.Size = new System.Drawing.Size(60, 23);
            this.txtValor2.TabIndex = 16;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(219, 17);
            this.label19.TabIndex = 15;
            this.label19.Text = "Somar constante em uma coluna:";
            // 
            // dlgMatriz1
            // 
            this.dlgMatriz1.FileName = "openFileDialog1";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnExcluirMatriz2);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.nudColunas2);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.nudLinhas2);
            this.groupBox4.Controls.Add(this.btnLerArq2);
            this.groupBox4.Controls.Add(this.btnCriar2);
            this.groupBox4.Location = new System.Drawing.Point(222, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(208, 217);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Criação da matriz 2";
            // 
            // btnExcluirMatriz2
            // 
            this.btnExcluirMatriz2.Location = new System.Drawing.Point(103, 184);
            this.btnExcluirMatriz2.Name = "btnExcluirMatriz2";
            this.btnExcluirMatriz2.Size = new System.Drawing.Size(101, 27);
            this.btnExcluirMatriz2.TabIndex = 10;
            this.btnExcluirMatriz2.Text = "Excluir matriz";
            this.btnExcluirMatriz2.UseVisualStyleBackColor = true;
            this.btnExcluirMatriz2.Click += new System.EventHandler(this.btnPrintar2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Colunas";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "Linhas";
            // 
            // nudColunas2
            // 
            this.nudColunas2.Location = new System.Drawing.Point(71, 144);
            this.nudColunas2.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudColunas2.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudColunas2.Name = "nudColunas2";
            this.nudColunas2.Size = new System.Drawing.Size(60, 23);
            this.nudColunas2.TabIndex = 6;
            this.nudColunas2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(176, 17);
            this.label12.TabIndex = 5;
            this.label12.Text = "Criar a partir do programa:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(196, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Criar a partir de arquivo texto:";
            // 
            // nudLinhas2
            // 
            this.nudLinhas2.Location = new System.Drawing.Point(71, 115);
            this.nudLinhas2.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudLinhas2.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nudLinhas2.Name = "nudLinhas2";
            this.nudLinhas2.Size = new System.Drawing.Size(60, 23);
            this.nudLinhas2.TabIndex = 3;
            this.nudLinhas2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // btnLerArq2
            // 
            this.btnLerArq2.Location = new System.Drawing.Point(6, 46);
            this.btnLerArq2.Name = "btnLerArq2";
            this.btnLerArq2.Size = new System.Drawing.Size(92, 28);
            this.btnLerArq2.TabIndex = 1;
            this.btnLerArq2.Text = "Ler arquivo";
            this.btnLerArq2.UseVisualStyleBackColor = true;
            this.btnLerArq2.Click += new System.EventHandler(this.btnLerArq2_Click);
            // 
            // btnCriar2
            // 
            this.btnCriar2.Location = new System.Drawing.Point(6, 184);
            this.btnCriar2.Name = "btnCriar2";
            this.btnCriar2.Size = new System.Drawing.Size(97, 27);
            this.btnCriar2.TabIndex = 0;
            this.btnCriar2.Text = "Criar matriz";
            this.btnCriar2.UseVisualStyleBackColor = true;
            this.btnCriar2.Click += new System.EventHandler(this.btnCriar2_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.cbxMatrizes2);
            this.groupBox5.Controls.Add(this.lblRetorno);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.nudColunas4);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.nudLinhas4);
            this.groupBox5.Controls.Add(this.btnPesquisar);
            this.groupBox5.Location = new System.Drawing.Point(436, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(208, 217);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Pesquisa de itens";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 17);
            this.label18.TabIndex = 14;
            this.label18.Text = "Escolha a matriz:";
            // 
            // cbxMatrizes2
            // 
            this.cbxMatrizes2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMatrizes2.FormattingEnabled = true;
            this.cbxMatrizes2.Location = new System.Drawing.Point(9, 43);
            this.cbxMatrizes2.Name = "cbxMatrizes2";
            this.cbxMatrizes2.Size = new System.Drawing.Size(112, 24);
            this.cbxMatrizes2.TabIndex = 13;
            this.cbxMatrizes2.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // lblRetorno
            // 
            this.lblRetorno.AutoSize = true;
            this.lblRetorno.Location = new System.Drawing.Point(6, 160);
            this.lblRetorno.Name = "lblRetorno";
            this.lblRetorno.Size = new System.Drawing.Size(45, 17);
            this.lblRetorno.TabIndex = 12;
            this.lblRetorno.Text = "Valor:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(152, 17);
            this.label17.TabIndex = 11;
            this.label17.Text = "do elemento desejado:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 138);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 17);
            this.label14.TabIndex = 8;
            this.label14.Text = "Coluna";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 111);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 17);
            this.label15.TabIndex = 7;
            this.label15.Text = "Linha";
            // 
            // nudColunas4
            // 
            this.nudColunas4.Location = new System.Drawing.Point(71, 136);
            this.nudColunas4.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudColunas4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColunas4.Name = "nudColunas4";
            this.nudColunas4.Size = new System.Drawing.Size(60, 23);
            this.nudColunas4.TabIndex = 6;
            this.nudColunas4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 70);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(160, 17);
            this.label16.TabIndex = 5;
            this.label16.Text = "Digite a linha e a coluna";
            // 
            // nudLinhas4
            // 
            this.nudLinhas4.Location = new System.Drawing.Point(71, 109);
            this.nudLinhas4.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudLinhas4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudLinhas4.Name = "nudLinhas4";
            this.nudLinhas4.Size = new System.Drawing.Size(60, 23);
            this.nudLinhas4.TabIndex = 3;
            this.nudLinhas4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(9, 184);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(89, 27);
            this.btnPesquisar.TabIndex = 0;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // frmMatriz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 684);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.dgvMatriz3);
            this.Controls.Add(this.dgvMatriz2);
            this.Controls.Add(this.dgvMatriz1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMatriz";
            this.Text = "Matrizes Esparsas";
            this.Load += new System.EventHandler(this.frmMatriz_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatriz3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColuna5)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudColunas4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLinhas4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLerArq1;
        private System.Windows.Forms.Button btnCriar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudColunas1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudLinhas1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbxMatrizes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudColunas3;
        private System.Windows.Forms.NumericUpDown nudLinhas3;
        private System.Windows.Forms.Button btnInserir;
        private System.Windows.Forms.DataGridView dgvMatriz1;
        private System.Windows.Forms.DataGridView dgvMatriz2;
        private System.Windows.Forms.DataGridView dgvMatriz3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.OpenFileDialog dlgMatriz1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nudColunas2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nudLinhas2;
        private System.Windows.Forms.Button btnLerArq2;
        private System.Windows.Forms.Button btnCriar2;
        private System.Windows.Forms.Button btnExcluirMatriz1;
        private System.Windows.Forms.Button btnExcluirMatriz2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblRetorno;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown nudColunas4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown nudLinhas4;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbxMatrizes2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.NumericUpDown nudColuna5;
        private System.Windows.Forms.TextBox txtValor2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbxMatriz3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnSomarDuasMatrizes;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnMulti;
        private System.Windows.Forms.ComboBox cbxDuasMatrizesAmultiplicar;
        private System.Windows.Forms.Button btnRemover;
    }
}

